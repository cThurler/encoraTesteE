/**
 * 
 */
/**
 * 
 */
module encora {
}